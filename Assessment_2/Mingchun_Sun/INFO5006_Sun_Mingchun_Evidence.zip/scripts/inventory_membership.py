"""Record observed assignments and out-of-reference candidates; no relevance classifier."""
from pathlib import Path
import argparse
import pandas as pd
p=argparse.ArgumentParser();p.add_argument('--base',type=Path,required=True);a=p.parse_args()
t=pd.read_csv(a.base/'job_titles_cleaned.csv')
s=pd.read_csv(a.base/'skills_repo/Bingqi_Yan_skills_competencies_cleaned.csv')
out=a.base/'job_titles_analysis';out.mkdir(exist_ok=True)
t.groupby(['job_title_clean','role_family','seniority_from_title']).size().rename('postings').reset_index().to_csv(out/'observed_title_membership.csv',index=False)
z=s.loc[~s.job_link.isin(t.job_link),['job_link','job_title']].drop_duplicates().sort_values(['job_link','job_title'])
z.to_csv(out/'outside_reference_skill_candidates.csv',index=False)
print({'skill_rows':len(s),'skill_links':s.job_link.nunique(),'outside_links':z.job_link.nunique()})
