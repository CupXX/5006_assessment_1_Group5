"""Reproduce local INFO5006 title/skill descriptives. No source files modified.
Run: python analyze.py [--base PATH]
Requires pandas, numpy, matplotlib. CSV outputs use UTF-8.
"""
from pathlib import Path
import argparse, hashlib, json, re
import pandas as pd
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

parser=argparse.ArgumentParser()
parser.add_argument('--base',default='.')
a=parser.parse_args(); base=Path(a.base); out=base/'job_titles_analysis'; out.mkdir(exist_ok=True)
t=pd.read_csv(base/'job_titles_cleaned.csv',keep_default_na=False)
s=pd.read_csv(base/'skills_analysis/skills_titles_joined.csv',keep_default_na=False)
assert len(t)==4532 and t.job_link.is_unique
assert s.job_link.nunique()==4346
assert set(s.job_link)<=set(t.job_link)
assert not s.duplicated(['job_link','skill_standard']).any()
for col in ['role_family','job_level','seniority_from_title']:
    assert s.set_index('job_link')[col].eq(s.job_link.map(t.set_index('job_link')[col]).values).all()
t['has_skills']=t.job_link.isin(s.job_link)
def save(df,name): df.to_csv(out/(name+'.csv'),index=False)
dist={}
for col in ['role_family','title_match_type','seniority_from_title','job_level','job_type','search_country']:
    d=t[col].value_counts().rename_axis(col).rename('postings').reset_index()
    d['pct_all_postings']=d.postings/len(t)*100
    save(d,'distribution_'+col); dist[col]=d.to_dict('records')
cov=t.groupby('role_family').has_skills.agg(observed='sum',total='size').reset_index()
cov['missing']=cov.total-cov.observed; cov['coverage_pct']=100*cov.observed/cov.total
save(cov,'coverage_role')
counts=s.groupby(['role_family','skill_standard']).job_link.nunique().rename('postings').reset_index().merge(cov,on='role_family',validate='many_to_one')
counts['pct_observed']=100*counts.postings/counts.observed
counts['pct_all_lower_bound']=100*counts.postings/counts.total
counts['pct_all_upper_bound']=100*(counts.postings+counts.missing)/counts.total
save(counts,'skill_prevalence_role_bounds')
top=s.groupby('skill_standard').job_link.nunique().sort_values(ascending=False).rename('postings').reset_index()
top['pct_observed']=100*top.postings/4346; top['pct_all_lower_bound']=100*top.postings/4532
save(top,'skill_prevalence_overall')
selected=top.head(10).skill_standard.tolist()
save(counts[counts.skill_standard.isin(selected)],'top10_skill_comparison')
cat=s.groupby('skill_category').agg(posting_skill_pairs=('job_link','size'),postings=('job_link','nunique')).reset_index()
cat['pct_pairs']=100*cat.posting_skill_pairs/len(s); cat['pct_observed_postings']=100*cat.postings/4346
save(cat,'category_diagnostics')
save(pd.crosstab(t.seniority_from_title,t.job_level).reset_index(),'seniority_vs_job_level')
role_level=pd.crosstab(t.role_family,t.job_level)
save(role_level.reset_index(),'role_vs_job_level_counts')
save(role_level.div(role_level.sum(axis=1),axis=0).mul(100).reset_index(),'role_vs_job_level_row_pct')
save(t.job_title_clean.value_counts().rename_axis('job_title_clean').rename('postings').reset_index(),'clean_title_counts')
# Sensitivity only: exact generic titles, case-insensitive, optional rank and grade.
# This is an explicit analyst-defined restriction, not a reconstruction of original cleaning.
pattern=r'(?:(?:senior|sr\.?|junior|jr\.?|lead|principal|associate)\s+)?business(?:\s+systems)?\s+analyst(?:\s+(?:i{1,3}|iv|v|[1-5]))?'
t['strict_generic']=t.job_title_clean.str.strip().str.fullmatch(pattern,case=False)
t['business_analyst_match']=t.title_match_type.eq('Business Analyst title')
t['plan_whole_phrase_raw']=t.job_title_raw.str.contains(r'\bbusiness\s+analysts?\b',case=False,regex=True)
assert t.plan_whole_phrase_raw.sum()==3734
sens=[]
for name,mask in [('All supplied titles',pd.Series(True,index=t.index)),('Group-plan whole phrase in raw title',t.plan_whole_phrase_raw),('Business Analyst match type only',t.business_analyst_match),('Strict generic BA or BSA title',t.strict_generic)]:
    z=t[mask]; zs=s[s.job_link.isin(z.job_link)]; n=zs.job_link.nunique()
    v=zs.groupby('skill_standard').job_link.nunique().reindex(selected,fill_value=0)
    for skill,k in v.items():sens.append({'subset':name,'titles':len(z),'observed':n,'coverage_pct':100*n/len(z),'skill_standard':skill,'postings':k,'pct_observed':100*k/n})
save(pd.DataFrame(sens),'sensitivity_top_skills')
save(t[['job_link','job_title_raw','job_title_clean','role_family','plan_whole_phrase_raw','strict_generic','business_analyst_match']],'sensitivity_membership')
save(t.groupby(['role_family','plan_whole_phrase_raw']).size().unstack(fill_value=0).reset_index(),'plan_filter_by_role')
sample=pd.concat([g.sort_values('job_link').sample(n=min(8,len(g)),random_state=5006) for _,g in t.groupby('role_family')])
sample=sample[['job_link','job_title_clean','role_family']].copy()
sample['review_scope']='Title wording only; no job description or independent gold standard'
sample['review_note']='Title wording supports the supplied family; does not verify actual duties.'
notes={
'Finance Business Analyst (Anaplan)':'Finance and platform cues coexist; category priority is not documented.',
'Business Analyst (with Credit Card)':'Credit-card cue supports a financial domain; actual duties remain unknown.',
'Business Analyst III - Accounting & Data Governance, IS Operational Experience':'Accounting, data and operational cues coexist; single-family assignment is lossy.',
'Business Analyst - With Pega preferred - Westlake TX (W2 OR C2C) $ 70/hr':'Pega is a platform cue but assigned Functional / Domain; possible rule or keyword overlap to review.',
'Business Analyst with Commercial Lending':'Financial domain cue but assigned Functional / Domain rather than Finance; review taxonomy boundary.',
'Saleforce Business Analyst (Service Focused)':'Possible Salesforce misspelling may evade platform mapping; verify before correction.',
'Business Analyst w/ LIMS':'Named system cue retained in Other / Hybrid; review platform boundary.',
'Senior Business Analyst - Anti-Money Laundering':'Financial-compliance cue retained in Other / Hybrid; review finance/domain boundary.',
}
for title,note in notes.items():sample.loc[sample.job_title_clean.eq(title),'review_note']=note
sample.loc[sample.role_family.eq('Other / Hybrid Business Analyst') & ~sample.job_title_clean.isin(notes),'review_note']='Residual label cannot be validated from title alone; grade, identifier or location text does not establish a hybrid role.'
save(sample,'title_audit_48')
company=t.company.value_counts().rename_axis('company').rename('postings').reset_index();save(company,'company_counts')
duplicate=t.duplicated(['job_title_clean','company','job_location'],keep=False)
save(t[duplicate], 'repeated_title_company_location_review')
summary={'title_rows':len(t),'unique_job_links':t.job_link.nunique(),'observed_skill_jobs':4346,'missing_skill_jobs':186,'coverage_pct':100*4346/4532,'matched_skill_pairs':len(s),'unique_skill_strings':s.skill_standard.nunique(),'unclassified_pair_pct':100*s.skill_category.eq('Unclassified').mean(),'changed_title_rows':int(t.job_title_raw.ne(t.job_title_clean).sum()),'unique_titles':t.job_title_clean.nunique(),'unique_companies':t.company.nunique(),'extra_repeated_title_company_location_rows':int(t.duplicated(['job_title_clean','company','job_location']).sum()),'rows_in_repeated_title_company_location_groups':int(duplicate.sum()),'strict_generic_n':int(t.strict_generic.sum()),'dates':[t.first_seen.min(),t.first_seen.max()],'distributions':dist,'source_sha256':{str(p.relative_to(base)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [base/'job_titles_cleaned.csv',base/'skills_analysis/skills_titles_joined.csv']}}
(out/'summary.json').write_text(json.dumps(summary,indent=2))
plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False})
short={'Core Business Analyst':'Core','ERP / Platform Business Analyst':'ERP / Platform','Finance Business Analyst':'Finance','Functional / Domain Business Analyst':'Functional / Domain','Other / Hybrid Business Analyst':'Other / Hybrid','Systems / Technology Business Analyst':'Systems / Technology'}
d=pd.DataFrame(dist['role_family']).sort_values('postings')
fig,ax=plt.subplots(figsize=(9,4.5)); ax.barh(d.role_family.map(short),d.postings,color='#336b91');
for i,(_,r) in enumerate(d.iterrows()):ax.text(r.postings+12,i,f'{r.postings:,} ({r.pct_all_postings:.1f}%)',va='center')
ax.set_xlim(0,1750);ax.set_xlabel('Postings (N = 4,532)');ax.set_title('Supplied role-family distribution');fig.tight_layout();fig.savefig(out/'role_distribution.png',dpi=180);plt.close(fig)
fig,ax=plt.subplots(figsize=(9,4.5));c=cov.sort_values('coverage_pct');ax.barh(c.role_family.map(short),c.coverage_pct,color='#336b91')
for i,(_,r) in enumerate(c.iterrows()):ax.text(r.coverage_pct+1,i,f'{r.observed}/{r.total} ({r.coverage_pct:.1f}%)',va='center')
ax.set_xlim(0,133);ax.set_xlabel('Postings with any matched skill record (%)');ax.set_title('Skill coverage differs materially by role');fig.tight_layout();fig.savefig(out/'skill_coverage.png',dpi=180);plt.close(fig)
matrix=counts[counts.skill_standard.isin(selected)].pivot(index='skill_standard',columns='role_family',values='pct_observed').reindex(selected).fillna(0)
fig,ax=plt.subplots(figsize=(10,6));im=ax.imshow(matrix.values,cmap='Blues',vmin=0,vmax=70,aspect='auto');ax.set_yticks(range(len(matrix)),matrix.index);ax.set_xticks(range(len(matrix.columns)),[f'{short[x]}\n(n={int(cov.set_index("role_family").loc[x,"observed"])})' for x in matrix.columns],rotation=25,ha='right')
for i in range(matrix.shape[0]):
 for j in range(matrix.shape[1]):ax.text(j,i,f'{matrix.iloc[i,j]:.1f}',ha='center',va='center',color='white' if matrix.iloc[i,j]>42 else 'black')
ax.set_title('Top 10 overall skills: % of skill-observed postings in each role');fig.colorbar(im,ax=ax,label='% of observed postings');fig.tight_layout();fig.savefig(out/'skill_heatmap.png',dpi=180);plt.close(fig)
print(json.dumps({k:v for k,v in summary.items() if k not in ['distributions','source_sha256']},indent=2))
print(counts[counts.skill_standard.isin(['sql','communication','data analysis','business analysis'])][['role_family','skill_standard','postings','observed','pct_observed']].to_string(index=False))
print(pd.DataFrame(sens).to_string(index=False))
