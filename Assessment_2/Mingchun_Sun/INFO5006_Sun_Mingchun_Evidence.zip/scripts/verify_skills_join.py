import json
from pathlib import Path
import pandas as pd
import argparse
parser=argparse.ArgumentParser()
parser.add_argument('--base', default='.')
base=Path(parser.parse_args().base)
(base/'skills_analysis').mkdir(parents=True, exist_ok=True)
t=pd.read_csv(base/'job_titles_cleaned.csv')
s=pd.read_csv(base/'skills_repo/Bingqi_Yan_skills_competencies_cleaned.csv')
assert t.job_link.notna().all() and t.job_link.is_unique
assert not s[['job_link','skill_standard']].isna().any().any()
# One binary occurrence per posting and standardized skill, even if future data duplicate.
pairs=s.drop_duplicates(['job_link','skill_standard'])
joined=pairs.merge(t[['job_link','role_family','job_level','seniority_from_title']],on='job_link',how='inner',validate='many_to_one')
joined.to_csv(base/'skills_analysis/skills_titles_joined.csv',index=False)
coverage=t.assign(has_skills=t.job_link.isin(s.job_link))
for group in ['role_family','job_level','seniority_from_title']:
    cov=coverage.groupby(group).has_skills.agg(observed='sum',total='count')
    cov['coverage_pct']=100*cov.observed/cov.total
    cov.to_csv(base/f'skills_analysis/coverage_by_{group}.csv')
    counts=joined.groupby([group,'skill_standard']).job_link.nunique().rename('postings').reset_index()
    counts=counts.merge(cov,on=group,validate='many_to_one')
    counts['pct_all_postings']=100*counts.postings/counts.total
    counts['pct_skill_observed_postings']=100*counts.postings/counts.observed
    counts.to_csv(base/f'skills_analysis/skill_prevalence_by_{group}.csv',index=False)
print(json.dumps({'titles':len(t),'skill_rows':len(s),'skill_jobs':s.job_link.nunique(),'matched_jobs':joined.job_link.nunique(),'matched_unique_pairs':len(joined),'duplicate_original_pairs':int(s.duplicated(['job_link','skill_standard']).sum()),'unclassified_matched_pair_pct':100*joined.skill_category.eq('Unclassified').mean()},indent=2))
