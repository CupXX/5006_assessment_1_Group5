# Geographic analysis supporting files

- `state_comparison.csv`: all 50 states and the District of Columbia, with selected BA and eligible baseline counts and shares.
- `reference_geography.csv`: the group's 4,532 selected job links and their geographic mapping status. `Unresolved metro area` denotes the seven conservatively corrected labels.
- `diagnostics.json`: matching, coverage and geographic correction checks.
- `sensitivity_by_date_and_state.csv`: selected BA and baseline counts by date and location.
- `sensitivity_date_standardization.csv`: pooled and date-standardised selected BA / baseline rates by location. Small daily cells and selection bias limit interpretation.
- `analyse_geography.py` and `check_date_sensitivity.py`: Python standard-library scripts that reproduce these outputs using the original and prepared datasets. Their `SOURCE` or `source` path points to the original local Assessment 1 folder; change it and retain the folder structure for another computer. The input data files are not included in this folder because they are large. Scripts write their CSV and JSON results in the same folder as the script.

Both scripts require the following inputs: `linkedin_job_postings.csv`, `Yanzhang_Xie_geography_prepared.csv`, and `Assessment 1 Cleaned Data/Mingchun_Sun_Member2_Job_Titles_Cleaned.csv`. The latter is the sole selected BA reference list. `first_seen` is not necessarily the original publication date. These materials describe the supplied data, not the complete US labour market.
