import csv, json
from collections import Counter
from pathlib import Path

# Edit SOURCE to the folder containing the supplied Assessment 1 CSV files.
SOURCE = Path(r'D:\ADELAIDE UNIVERSITY\Business Intelligence\Assessement 1')
OUT = Path(__file__).resolve().parent
reference_file = SOURCE / 'Assessment 1 Cleaned Data' / 'Mingchun_Sun_Member2_Job_Titles_Cleaned.csv'

def read(path):
    return csv.DictReader(path.open(encoding='utf-8-sig', newline=''))

reference = {row['job_link'].strip() for row in read(reference_file)}
assert len(reference) == 4532
jobs = {}
for row in read(SOURCE / 'linkedin_job_postings.csv'):
    key = row['job_link'].strip()
    if key and row['search_country'].strip() == 'United States' and row['first_seen'].startswith('2024-'):
        if key in jobs:
            raise ValueError('Duplicate eligible job_link')
        jobs[key] = row['first_seen'].strip()
ambiguous = {'New York City Metropolitan Area', 'Washington DC-Baltimore Area',
             'Oklahoma City Metropolitan Area', 'Kansas City Metropolitan Area',
             'Greater Colorado Springs Area', 'Iowa City-Cedar Rapids Area', 'Greater Idaho Falls'}
base, selected = Counter(), Counter()
seen = set()
for row in read(SOURCE / 'Yanzhang_Xie_geography_prepared.csv'):
    key = row['job_link'].strip()
    if key not in jobs:
        continue
    if key in seen:
        raise ValueError('Duplicate prepared job_link')
    seen.add(key)
    state = row['state'].strip()
    if row['state_mapping_status'] != 'Mapped' or not state or row['job_location'].strip() in ambiguous:
        continue
    pair = (state, jobs[key])
    base[pair] += 1
    if key in reference:
        selected[pair] += 1
assert len(seen) == len(jobs)
assert sum(base.values()) == 1129520 and sum(selected.values()) == 4440
states = sorted({state for state, day in base})
days = sorted({day for state, day in base})
base_dates = {day: sum(base[(state, day)] for state in states) for day in days}
selected_dates = {day: sum(selected[(state, day)] for state in states) for day in days}
by_day = []
for day in days:
    for state in states:
        b, n = base[(state, day)], selected[(state, day)]
        by_day.append({'date': day, 'state': state, 'wide_postings': n, 'baseline_postings': b,
                       'wide_pct_of_baseline': 100*n/b if b else '',
                       'wide_share_of_day_pct': 100*n/selected_dates[day] if selected_dates[day] else '',
                       'baseline_share_of_day_pct': 100*b/base_dates[day] if b else ''})
with (OUT / 'sensitivity_by_date_and_state.csv').open('w', encoding='utf-8-sig', newline='') as f:
    w = csv.DictWriter(f, fieldnames=list(by_day[0])); w.writeheader(); w.writerows(by_day)
standardized = []
for state in states:
    if any(base[(state, day)] == 0 for day in days):
        continue
    n, b = sum(selected[(state, day)] for day in days), sum(base[(state, day)] for day in days)
    rate = sum(base_dates[day]/sum(base_dates.values()) * selected[(state, day)]/base[(state, day)] for day in days)
    standardized.append({'state':state, 'overall_rate_pct':100*n/b, 'standardized_rate_pct':100*rate,
                         'ba_count':n, 'all_count':b})
standardized.sort(key=lambda row: -row['standardized_rate_pct'])
with (OUT / 'sensitivity_date_standardization.csv').open('w', encoding='utf-8-sig', newline='') as f:
    w = csv.DictWriter(f, fieldnames=list(standardized[0])); w.writeheader(); w.writerows(standardized)
summary = {'reference_total':len(reference), 'reference_mapped':sum(selected.values()),
           'baseline_mapped':sum(base.values()), 'reference_mapped_dates':selected_dates,
           'baseline_mapped_dates':base_dates}
(OUT / 'date_checks.json').write_text(json.dumps(summary, indent=2), encoding='utf-8')
print(json.dumps(summary, indent=2))
