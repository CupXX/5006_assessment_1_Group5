import csv, json, re
from collections import Counter
from pathlib import Path

source = Path(r'D:\ADELAIDE UNIVERSITY\Business Intelligence\Assessement 1')
out = Path(__file__).resolve().parent
ref_file = source / 'Assessment 1 Cleaned Data' / 'Mingchun_Sun_Member2_Job_Titles_Cleaned.csv'

def read(path):
    return csv.DictReader(path.open(encoding='utf-8-sig', newline=''))

ref = {}
for row in read(ref_file):
    key = row['job_link'].strip()
    if not key or key in ref:
        raise ValueError('Reference has missing or duplicate job_link')
    ref[key] = row
assert len(ref) == 4532
eligible = set()
source_ref = {}
source_duplicates = 0
for row in read(source / 'linkedin_job_postings.csv'):
    key = row['job_link'].strip()
    if key in ref:
        if key in source_ref:
            source_duplicates += 1
        source_ref[key] = row
    if row['search_country'].strip() == 'United States' and row['first_seen'].strip().startswith('2024-'):
        if key in eligible:
            source_duplicates += 1
        if key:
            eligible.add(key)

baseline = Counter()
ba_states = Counter()
status = Counter()
mapped_ref = {}
seen_eligible = set()
duplicates = 0
mismatch = []
# These labels name cities or multi-state metro areas, not an explicit state.
# Apply the same conservative correction to the reference and baseline.
ambiguous_metros = {
    'New York City Metropolitan Area', 'Washington DC-Baltimore Area',
    'Oklahoma City Metropolitan Area', 'Kansas City Metropolitan Area',
    'Greater Colorado Springs Area', 'Iowa City-Cedar Rapids Area',
    'Greater Idaho Falls',
}
corrected = Counter()
for row in read(source / 'Yanzhang_Xie_geography_prepared.csv'):
    key = row['job_link'].strip()
    if key not in eligible:
        continue
    if key in seen_eligible:
        duplicates += 1
        continue
    seen_eligible.add(key)
    if row['state_mapping_status'] == 'Mapped' and row['job_location'].strip() in ambiguous_metros:
        corrected[row['job_location'].strip()] += 1
        row['state'] = ''
        row['state_mapping_status'] = 'Unresolved metro area'
    if row['state_mapping_status'] == 'Mapped' and row['state']:
        baseline[row['state']] += 1
    if key in ref:
        mapped_ref[key] = row
        status[row['state_mapping_status']] += 1
        if row['state_mapping_status'] == 'Mapped' and row['state']:
            ba_states[row['state']] += 1
        original = source_ref.get(key)
        if original and original['job_location'].strip() != row['job_location'].strip():
            mismatch.append(key)

n_ba = sum(ba_states.values())
n_all = sum(baseline.values())
assert sum(baseline.values()) == n_all and sum(ba_states.values()) == n_ba
assert len(eligible) == len(seen_eligible) + len(eligible - seen_eligible)
rows = []
for state in sorted(set(baseline) | set(ba_states)):
    a, b = ba_states[state], baseline[state]
    p = a / n_ba * 100 if n_ba else 0
    q = b / n_all * 100 if n_all else 0
    rows.append({'state': state, 'ba_postings': a, 'ba_share_pct': p, 'all_postings': b, 'all_share_pct': q, 'share_difference_pp': p-q, 'relative_share_ratio': p/q if q else ''})
rows.sort(key=lambda r: -r['ba_postings'])
with (out / 'state_comparison.csv').open('w',encoding='utf-8-sig',newline='') as f:
    w = csv.DictWriter(f,fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
with (out / 'reference_geography.csv').open('w',encoding='utf-8-sig',newline='') as f:
    fields=['job_link','job_title','job_location','state','state_mapping_status','reference_title_match_type','source_match']
    w=csv.DictWriter(f,fieldnames=fields); w.writeheader()
    for key,r in ref.items():
        m=mapped_ref.get(key,{})
        w.writerow({'job_link':key,'job_title':r['job_title_raw'],'job_location':m.get('job_location',r.get('job_location','')),'state':m.get('state',''),'state_mapping_status':m.get('state_mapping_status','Not matched to eligible prepared data'),'reference_title_match_type':r['title_match_type'],'source_match':key in source_ref})
diagnostics={'reference_n':len(ref),'source_reference_matches':len(source_ref),'reference_not_in_source':len(set(ref)-set(source_ref)),'reference_not_eligible':len(set(ref)-eligible),'reference_prepared_matches':len(mapped_ref),'reference_unmatched_prepared':len(set(ref)-set(mapped_ref)),'reference_status':dict(status),'ba_mapped_n':n_ba,'eligible_us_source_n':len(eligible),'eligible_prepared_matches':len(seen_eligible),'eligible_missing_prepared':len(eligible-seen_eligible),'eligible_mapped_n':n_all,'duplicates_source_observed':source_duplicates,'duplicates_prepared_eligible':duplicates,'location_mismatch_reference':len(mismatch),'date_note':'first_seen starts 2024-; search_country exactly United States','baseline_note':'includes BA reference postings','metro_corrections_eligible':dict(corrected)}
(out / 'diagnostics.json').write_text(json.dumps(diagnostics,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(diagnostics,ensure_ascii=False,indent=2))
print('\nTOP STATES')
for row in rows[:12]: print(row)

